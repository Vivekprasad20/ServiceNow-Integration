## Quick login to current instance

If you frequently have to login to the currently used instance with a different user (e.g. with your admin account), this Bookmarklet will be a huge timesaver for you!

All you have to do is to click the Bookmarklet, and a popup window will appear with the current Servicenow instance's login page. After you enter your credentials (or your password manager enters it), the popup will close, and the page will reload to log you in.
