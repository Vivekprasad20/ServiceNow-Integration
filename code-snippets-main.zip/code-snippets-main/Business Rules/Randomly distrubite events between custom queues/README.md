This business rule helps generate multiple events, which are randomly and almost perfetly even distributed by a specified number of custom queues. 
