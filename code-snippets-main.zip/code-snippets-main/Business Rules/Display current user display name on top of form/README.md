**Use case :**
 Display info message with current user display name on top of a form
 
 **Soulution :**
 Write a "Display business rule" on any table using `GlideSystem - getUserDisplayName()` API <br/>
 Check script.js file for example
