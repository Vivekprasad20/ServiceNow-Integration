Code will copy attachments from idea to demand

Name: Copy attachments to demand

Table: Idea

When: Async

Filter conditions: demand changes and demand is not empty

Update: true

