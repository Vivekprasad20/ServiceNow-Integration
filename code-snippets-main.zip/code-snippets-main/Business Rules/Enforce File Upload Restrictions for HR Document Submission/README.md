This code ensures that when a user uploads a document related to a specific HR task, the uploaded file meets
certain criteria: it must be in JPG or JPEG format and must not exceed 2 MB in size. If either condition is violated,
the upload is halted, and an appropriate error message is displayed to the user, maintaining the integrity of the data 
being processed.
