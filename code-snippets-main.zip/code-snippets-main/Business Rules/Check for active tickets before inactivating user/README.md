This BR is designed to identify all active tickets from the "tables" array in ServiceNow and if there are any active tickets are found then the user would not be inactivated.
This BR helps administrators easily to find all the active tickets that assigned to the user who is being deactivated so that they can notify the management about this inconsistancy.

Administrators can either notify the user or the assignment group managers so that the active tickets can be transferred to a different user so that this user can be deactivated.