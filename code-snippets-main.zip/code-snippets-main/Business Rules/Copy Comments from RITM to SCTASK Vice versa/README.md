 End user recent comments on RITM to be copied as task worknotes to any catalog tasks which is not Closed Complete/Closed Skipped/Cancelled so the assigne aware of recent updates of End users.

 
