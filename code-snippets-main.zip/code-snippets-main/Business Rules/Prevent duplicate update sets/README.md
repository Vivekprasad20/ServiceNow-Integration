This Business Rule will help to prevent duplicate names for update set. And this will display error message when there is duplicate name found for update set name.
