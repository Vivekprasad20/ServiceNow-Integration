This is After- Business rule Created on Incident Table.
In which I have enabled Both insert and Update check Box to true.
Intially, we will create a field called major Incident(true/false field).
If the user checks that and updates an Incident record Immediately a Problem record will be generated with the current values of the Incident
A pop up message will be displayed as well.
If we want we can even put the condition's that only an incident manager can enable this checkBox
Without Installing the Major Incident Managment plugin, we can use this. But this will provide limted features for free.
