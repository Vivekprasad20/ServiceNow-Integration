**Overview** : This Business Rule will automatically categorize incidents based on the defined keywords when a new incident is created.

**Setting Up the Business Rule**

**Name**: Automated Incident Categorization

**Table**: Incident [incident]

**When**: Before

**Insert**: Checked
