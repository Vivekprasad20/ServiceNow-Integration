This business rule is configured to run after a record is inserted in the sn_hr_core_case table (which is parent table for HR cases). 
with conditions subjcet person is VIP and when a case priority is high.

we are simply checking the conditions at the script level. (this can be checked at the condition level as well.)
and creating hr task 
