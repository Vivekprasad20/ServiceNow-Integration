This business rule will run on the [sys_email_log] table.
When to run: after, insert
Filter condition: Notification is [select the notification]

In the Advance> script> paste the code part.

This business rule will help to provide exceeded time information as a UI 
about the SLA in the worknotes of the ticket when it has been reached to certain time period(here it is 75%).
