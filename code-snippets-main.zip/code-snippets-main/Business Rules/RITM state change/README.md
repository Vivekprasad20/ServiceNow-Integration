# Create before insert/update business rule
business rule on sc_req_item table and give condition if state changes to 2 OR cat_item.sc.catalogs is "yourchoice"  and run this script.

This business is to set state on sc_task table when state changes on sc_req_item based on condition. 
