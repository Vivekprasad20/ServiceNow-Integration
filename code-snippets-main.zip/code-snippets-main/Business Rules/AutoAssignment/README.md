This Business Rule runs before an incident is inserted.
If no user is assigned, it looks up the "IT Support" group and assigns the incident to the group's manager.
This ensures that incidents are promptly directed to the appropriate personnel.
