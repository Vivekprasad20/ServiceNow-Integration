This business rule is used in the Change Management module to display a warning message when requested by and Peer reviewer are the same person. You need to run this business rule "before" you "insert" under the filter conditions.


