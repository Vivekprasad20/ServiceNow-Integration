This BR is created basically to close the parent requested item when ever the sc task is closed 
1. When: After
2. Update: true
3. Add filter condition as 
    1. State is one of closed complete or closed incomplete
    2. Catalog Item needs to be selected
4. Advanced check box needs to be checked
5. Refer to closeParentRITMwhenSCTaskisClosed.js
