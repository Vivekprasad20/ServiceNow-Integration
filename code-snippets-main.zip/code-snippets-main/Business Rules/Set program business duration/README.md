OOTB the project records exclude weekends and public holidays when calculating the duration, whereas program does not exclude these things. 

This business rule and associated script include address this issue and ensure that the duration field on the program record are calculated in the same way as projects.
