This Business Rule to send physical copy of attachment before insert on given table

Eg. Usecase- To send physical copy of attachment on email.

When to run - Before Insert
Table name- sys_email

Please note that correct Attachment sys_id to be mentioned in the code from Attachment table which need to be attached on email.
