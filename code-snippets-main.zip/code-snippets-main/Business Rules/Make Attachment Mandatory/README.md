This simple code snippet will help in making attachments mandotary.
Can be used in Before BR/Script Inculde.
