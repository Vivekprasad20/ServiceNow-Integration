Before Business rule for keeping a rank field unique.

Conditions: current.rank.changes() && !current.rank.nil()