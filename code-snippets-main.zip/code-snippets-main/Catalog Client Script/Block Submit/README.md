Code Snippet to block submission of catalog item based on answer to other yes/no variable.

#update
To fix a task from issue #745
Replace JavaScript alert() method to GlideModal() API.

