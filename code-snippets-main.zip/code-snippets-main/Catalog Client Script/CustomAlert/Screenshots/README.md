Please see the example Screenshots
