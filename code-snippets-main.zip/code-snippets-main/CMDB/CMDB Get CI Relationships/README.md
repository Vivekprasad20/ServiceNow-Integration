# Retrieve CI Relationships present for particular CMDB CI record 
This functionality allows users to obtain all configuration item (CI) relationships associated with a specific CMDB CI record. It provides detailed insights into how the selected CI is related to other CIs within the CMDB, enabling better management and understanding of infrastructure dependencies.
