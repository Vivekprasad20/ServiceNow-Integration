# Mandatory Field Analysis

Mandatory fields may cause discovery not to work as expected, especially if the mandatory field is also a custom field. 

This code snippet helps identify mandatory fields and can assist with remediating problematic configuration
