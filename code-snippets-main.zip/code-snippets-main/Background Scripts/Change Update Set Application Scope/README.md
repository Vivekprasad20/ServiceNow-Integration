# Change update set application scope
In ServiceNow, there are instances where an update set is mistakenly created in the incorrect application scope. To rectify this, I've developed a background script that facilitates the alteration of the update set's application scope to the appropriate one.
