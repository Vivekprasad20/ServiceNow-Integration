# hasRoleExactly

This background script might be useful if you come
in a situation where it would be necessary to check 
whether the logged in user has a specific role.

# Use Case: 
example: check if the user has a specific role by calling the role: hasRoleExactly('admin');
will return true if the user has the role and false otherwise

