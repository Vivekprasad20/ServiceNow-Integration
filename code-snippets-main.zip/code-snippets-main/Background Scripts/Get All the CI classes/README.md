This background script provides the names of all the available Ci classes present in the system
