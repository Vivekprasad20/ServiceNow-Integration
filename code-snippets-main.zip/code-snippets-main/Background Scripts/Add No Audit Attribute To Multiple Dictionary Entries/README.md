A background script add the no-audit attribute to multiple dictionary entries. 
The no-audit attribute will exclued the specified attributes from the system audit process and will not produc audit track at all.
