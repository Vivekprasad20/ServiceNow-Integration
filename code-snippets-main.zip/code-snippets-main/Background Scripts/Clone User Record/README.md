Clone a user to another user after creating a new user from SN and run the below script from Background Script under System Definition app. 
The sys id's are needed from both users to run the background script.
