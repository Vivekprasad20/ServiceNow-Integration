Script to be used to add bookmark for ITIL users. This will help add favorites for SLAs for
- My Group Tasks
- SLAs for My Tasks
- Tasks Assigned to Me
- My approvals
to all ITIL users.
Replace the addQuery value to get the favorites applied from the backend to required audience
