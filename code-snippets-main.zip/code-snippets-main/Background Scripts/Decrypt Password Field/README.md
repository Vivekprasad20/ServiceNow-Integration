Sometimes we forget the password we are using e.g. the Credentials records for integrations. 
With this code, you can go into the "basic_auth_credentials" table and decrypt the field "password" which is of the type password2.
The API GlideEncrypter does only work in the Global scope.


