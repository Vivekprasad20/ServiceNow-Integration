This script will work to notify the users if their password is going to expire in less than 7 days. 
Prerequisite : You will need to create an event first.
