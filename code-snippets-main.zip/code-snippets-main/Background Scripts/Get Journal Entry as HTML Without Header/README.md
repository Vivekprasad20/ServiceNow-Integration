# Get Journal Entry as HTML

This script can be used in a Business Rule or background script, or any other server-side script. It assumes the presence of the `current` object, but can be used with any positioned GlideRecord. 

## Use

Simply change `current` to whatever GlideRecord variable you're using, and change the `journalFieldName` variable so it contains the name of the journal field you want to get the value for.
