1.Take any comma separated string to be displayed in columns
2.Apply above logic
3.update to field /Print /Use this in mail scripts to include in the notification.
4. we can also add this arryUtils script include (to convert arry elements to colums)

![image](https://user-images.githubusercontent.com/42912180/195672456-f282c82e-8516-4925-9e71-c80da8329ef3.png)
