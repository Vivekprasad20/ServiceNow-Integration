Creating a background script to print the total count of all tables with a specific filter condition
