Background Script provides the list of installed plugins, version installed and version available for the upgrade in the instance 

Note: We need to set the basic auth credential in order for the script to work on the instance where we are running it. 
