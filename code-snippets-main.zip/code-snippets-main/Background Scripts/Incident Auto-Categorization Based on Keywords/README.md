# Incident Auto-Categorization Based on Keywords

This background script auto-categorizes uncategorized incidents based on keywords found in the short_description field, updating the incident with relevant categories (e.g., "Email", "Network"). 
