- Set the appName variable to the exact name of the application you’re checking (in this case as an example, Project Workspace).
- This script queries the Application [sys_app] table for a record with the specified name.
- If the application is found, it retrieves and prints the version. If not, it prints a message stating the application wasn’t found.
- This script will find the version of a specific application and output the version in the Scripts - Background logs.





