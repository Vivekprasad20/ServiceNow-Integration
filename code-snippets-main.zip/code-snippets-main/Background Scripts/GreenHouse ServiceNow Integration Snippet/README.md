This utility contains sample code to integrate ServiceNow with GreenHouse and pull employee files from GreenHouse in ServiceNow Employee Document Management OOB Table records.

Sample code queries HR profile which a filtered query of active users which has a valid greenhouse ID present in ServiceNow HR profile records.

REST message which calls Greenhouse REST API is using below REST endpoint.
https://developers.greenhouse.io/harvest.html#get-retrieve-candidate

Document Types sys_id can be mapped to relevant document types on your instance.



