These are few scripts to run from Background Script editor to get the instance info.
