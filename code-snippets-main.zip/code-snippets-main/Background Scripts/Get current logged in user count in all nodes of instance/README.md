
# Get current logged in user count in all nodes of instance

**Use case** : Background script that will print the count of all currently logged in users in the instance

*info* : This method is to achieve the above use-case just with one time run of background script

**Solution** : Open `Scripts - Background` from the application navigator and run the script present in [script.js](https://github.com/ServiceNowDevProgram/code-snippets/blob/main/Background%20Scripts/Get%20current%20logged%20in%20user%20count%20in%20all%20nodes%20of%20instance/script.js)
