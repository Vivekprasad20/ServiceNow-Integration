This is the simple code to run independently from AES -> Background Scripts module and convert the datetime from one time zone to other
