This snippet outputs a list of module types included in an update set.
By checking the included module types before committing an update set, you can be sure you aren't including any unintended updates.
