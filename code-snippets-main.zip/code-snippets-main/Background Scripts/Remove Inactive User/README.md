This code snippet helps to remove the inactive users from active groups. It won't delete the user record from "sys_user" table it will just delete the entry from the "sys_user_grmember" table.
