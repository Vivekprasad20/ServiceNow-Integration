This code is an example to encrypt or decrypt the payload using base64Encode and decode methods of GlideStringUtil API.
