# Get GlideRecord to a reference field using getRefRecord() method

**Use case** : Background script that retrieves the complete record of a reference field