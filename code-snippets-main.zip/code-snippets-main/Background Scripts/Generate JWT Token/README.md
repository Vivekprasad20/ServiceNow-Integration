
# Generate JWT Token
This is used to generate the JWT token from SN background script by using jwtAPI and the corresponding method:generateJWT()
