Use this script to check for duplicates (and delete if necessary) in a table based on 2 or more criteria. 
For reference: https://www.servicenow.com/community/developer-blog/search-for-duplicates-delete-based-on-2-columns/ba-p/2279274
