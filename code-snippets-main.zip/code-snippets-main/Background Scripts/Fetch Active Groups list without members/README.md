Sample code to clean up the Groups with no members.
This code help to get the Active groups list  with no members
