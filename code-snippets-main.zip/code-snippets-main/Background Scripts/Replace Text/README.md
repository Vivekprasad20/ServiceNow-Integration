Purpose of the script is to help replace text IT_SAP with IT_ERP for all the Groups in Group table containing IT_SAP as keyword.
It uses replace method which follows format replace(/'ABCD'/g,'PQR')
where ABCD is to be replaced with PQR
