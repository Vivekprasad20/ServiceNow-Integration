Using GlideAggregate function to find out tickets (tasks) with same number. OOB there happens to be a Unique checkbox at dictionary level
and if in case not set to True it might create duplicate numbered tickets.
Script will help find, ticekts if any.
