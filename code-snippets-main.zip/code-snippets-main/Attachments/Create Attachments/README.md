## Create an Attachment via script

You can create a Business Rule (ie: After Insert) to automatically create an Attachment. 

In this example we're creating a text file containing 'some data'. 

The file name is 'fileName.txt'
