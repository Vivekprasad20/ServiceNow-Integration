This feature requires a "Display" Business rule on [sc_task] to pass true/false to the scratchpad and then an "onLoad" Client Script to display a message on the Catalog Task form if the RITM has attachments.

The result is a message on the Catalog Task form (below the RITM field) indicating when a RITM has attachments.
